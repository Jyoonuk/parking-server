import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='yoonuk',
    application_name='aws-parking-api',
    app_uid='JhdFSh5WsMW26QWqlL',
    org_uid='e0597a91-b63e-4b95-92b6-d3df55fbf3c4',
    deployment_uid='09edf20f-8822-457b-9465-146bf554f915',
    service_name='aws-parking-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-parking-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
